--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.5 (Ubuntu 11.5-1.pgdg18.04+1)
-- Dumped by pg_dump version 11.5 (Ubuntu 11.5-1.pgdg18.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "db1-lab1";
--
-- Name: db1-lab1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "db1-lab1" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'ru_RU.UTF-8' LC_CTYPE = 'ru_RU.UTF-8';


ALTER DATABASE "db1-lab1" OWNER TO postgres;

\connect -reuse-previous=on "dbname='db1-lab1'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: contragents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contragents (
    "IPN" integer NOT NULL,
    name character varying(255) NOT NULL,
    phone_number character varying(15) NOT NULL
);


ALTER TABLE public.contragents OWNER TO postgres;

--
-- Name: goods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goods (
    id bigint NOT NULL,
    height integer NOT NULL,
    width integer NOT NULL,
    depth integer NOT NULL,
    weight integer NOT NULL,
    description character varying(255),
    invoice_num bigint NOT NULL
);


ALTER TABLE public.goods OWNER TO postgres;

--
-- Name: goods_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.goods_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.goods_id_seq OWNER TO postgres;

--
-- Name: goods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.goods_id_seq OWNED BY public.goods.id;


--
-- Name: goods_invoice_num_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.goods_invoice_num_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.goods_invoice_num_seq OWNER TO postgres;

--
-- Name: goods_invoice_num_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.goods_invoice_num_seq OWNED BY public.goods.invoice_num;


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.invoices (
    num bigint NOT NULL,
    date_departure date NOT NULL,
    date_arrival date,
    shipping_cost integer NOT NULL,
    sender_ipn integer NOT NULL,
    recipient_ipn integer NOT NULL,
    warehouse_dep_num bigint NOT NULL,
    warehouse_arr_num bigint NOT NULL
);


ALTER TABLE public.invoices OWNER TO postgres;

--
-- Name: invoices_num_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_num_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_num_seq OWNER TO postgres;

--
-- Name: invoices_num_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_num_seq OWNED BY public.invoices.num;


--
-- Name: invoices_warehouse_arr_num_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_warehouse_arr_num_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_warehouse_arr_num_seq OWNER TO postgres;

--
-- Name: invoices_warehouse_arr_num_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_warehouse_arr_num_seq OWNED BY public.invoices.warehouse_arr_num;


--
-- Name: invoices_warehouse_dep_num_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.invoices_warehouse_dep_num_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.invoices_warehouse_dep_num_seq OWNER TO postgres;

--
-- Name: invoices_warehouse_dep_num_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.invoices_warehouse_dep_num_seq OWNED BY public.invoices.warehouse_dep_num;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    num bigint NOT NULL,
    address character varying(255) NOT NULL,
    phone_number character varying(15) NOT NULL
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: warehouses_num_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouses_num_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.warehouses_num_seq OWNER TO postgres;

--
-- Name: warehouses_num_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouses_num_seq OWNED BY public.warehouses.num;


--
-- Name: goods id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods ALTER COLUMN id SET DEFAULT nextval('public.goods_id_seq'::regclass);


--
-- Name: goods invoice_num; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods ALTER COLUMN invoice_num SET DEFAULT nextval('public.goods_invoice_num_seq'::regclass);


--
-- Name: invoices num; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN num SET DEFAULT nextval('public.invoices_num_seq'::regclass);


--
-- Name: invoices warehouse_dep_num; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN warehouse_dep_num SET DEFAULT nextval('public.invoices_warehouse_dep_num_seq'::regclass);


--
-- Name: invoices warehouse_arr_num; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices ALTER COLUMN warehouse_arr_num SET DEFAULT nextval('public.invoices_warehouse_arr_num_seq'::regclass);


--
-- Name: warehouses num; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN num SET DEFAULT nextval('public.warehouses_num_seq'::regclass);


--
-- Data for Name: contragents; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2969.dat

--
-- Data for Name: goods; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2971.dat

--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2966.dat

--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/2968.dat

--
-- Name: goods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.goods_id_seq', 1, false);


--
-- Name: goods_invoice_num_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.goods_invoice_num_seq', 6, true);


--
-- Name: invoices_num_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_num_seq', 1, false);


--
-- Name: invoices_warehouse_arr_num_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_warehouse_arr_num_seq', 2, true);


--
-- Name: invoices_warehouse_dep_num_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.invoices_warehouse_dep_num_seq', 2, true);


--
-- Name: warehouses_num_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouses_num_seq', 1, false);


--
-- Name: contragents contragents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.contragents
    ADD CONSTRAINT contragents_pkey PRIMARY KEY ("IPN");


--
-- Name: goods goods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT goods_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (num);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (num);


--
-- Name: goods invoice_num; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goods
    ADD CONSTRAINT invoice_num FOREIGN KEY (invoice_num) REFERENCES public.invoices(num);


--
-- Name: invoices recipient_ipn; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT recipient_ipn FOREIGN KEY (recipient_ipn) REFERENCES public.contragents("IPN");


--
-- Name: invoices sender_ipn; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT sender_ipn FOREIGN KEY (sender_ipn) REFERENCES public.contragents("IPN");


--
-- Name: invoices warehouse_arr_num; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT warehouse_arr_num FOREIGN KEY (warehouse_arr_num) REFERENCES public.warehouses(num);


--
-- Name: invoices warehouse_dep_num; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT warehouse_dep_num FOREIGN KEY (warehouse_dep_num) REFERENCES public.warehouses(num);


--
-- PostgreSQL database dump complete
--

